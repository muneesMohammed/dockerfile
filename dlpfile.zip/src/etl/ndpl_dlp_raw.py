#!/usr/bin/env python
__filename__ = "ndpl_dlp_raw.py"
__author__ = "Philip Dawny Philip"
__email__ = "philip.dawny@nestgroup.net"
__date__ = "20/12/2022"
__status__ = "Production"
__description__ = """ This code uses Pyspark to read streaming data from Kafka and push the same to a Delta S3 bucket.
                    The timestamp, date and unique ID have been extracted from the message and set as new fields."""

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
import sys
# from pyspark.streaming.kafka import KafkaUtils
from pyspark.streaming import StreamingContext
from pyspark import SparkContext
# import pyspark.sql.streaming.trigger
def sparkIn(kafka_address,topic):
     # STARTING SPARK SESSION
    spark = SparkSession.builder.getOrCreate()
     # STREAMING IN DATA FROM KAFKA TO DF
    in_df = spark.readStream.format("kafka").option("kafka.bootstrap.servers", kafka_address).option("subscribe",topic).option("startingOffsets", "latest").load()
    return in_df
def parseData(in_df):
    parsed_df=in_df.select(col("value").cast("string").alias("message")) \
        .withColumn("timestamp", regexp_extract(col("message"), "\\[Date\\/Time\\(Server\\)\\] (.*?)(?: \\||$)", 1)) \
            .withColumn('date', to_date(col("timestamp"))).withColumn('uuid', regexp_extract(col('message'), "\\[Log ID\\] (.*?) \\|", 1))
    # TO EXTRACT TIMESTAMP FROM WITHIN THE MESSAGE
    # SETTING A NEW COLUM "DATE" FROM THE ABOVE TIMESTAMP - THIS DATE WILL BE USED FOR PARTITIONING
    # SELECTING THE LOG ID FROM WITHIN THE MESSAGE AND SETTING AS A NEW COLUMN "UUID"
    return parsed_df
def queryRun(parsed_df):
    # CODE BLOCK TO WRITE DF TO DELTA
    query = parsed_df.writeStream \
    .partitionBy("date") \
    .format("delta") \
    .outputMode("append") \
    .option("mergeSchema", "true") \
    .option("checkpointLocation", checkpoint_path) \
    .trigger(processingTime='20 seconds') \
    .start(DeltaPath)
    query.awaitTermination()         
if __name__ == '__main__':
    if len(sys.argv) != 6:
        print("Usage: spark_kafka_connect.py <kafka_hostname> <kafka_port> <checkpoint_path> <delta_path><topicname>", file=sys.stderr)
        sys.exit(-1)

    # RECEIVING ARGUMENTS ENTERED IN COMMAND LINE USING SYS:
    kafka_address = sys.argv[1] + ":" + sys.argv[2]
    checkpoint_path =sys.argv[3]
    DeltaPath = sys.argv[4]
    topic = sys.argv[5]
    in_df=sparkIn(kafka_address,topic)
    parsed_df=parseData(in_df)
    queryRun(parsed_df)

   
    


