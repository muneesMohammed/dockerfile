#!/usr/bin/env python
__filename__ = "ndpl_dlp_reporting.py"
__author__ = "Mohammed Munais"
__email__ = "mohammed.munais@nestgroup.net"
__date__ = "20/12/2022"
__status__ = "Production"
__description__ = """ This code uses Pyspark to read streaming data from process layer Delta S3 bucket.This data is then pushed into 
                      the reporting layer Delta S3 bucket. """

import sys
from pyspark.sql import *
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.streaming import *
from pyspark import SparkContext
import threading
from delta.tables import *
# from delta.tables import delta
import pyspark.sql.functions as F
from datetime import date
from datetime import timedelta

def inputData(input_path):
    
    # Create DataFrame representing the stream of input lines from connection to host:port
    input_df = spark.readStream.format("delta").load(input_path)
    return input_df
def tableSetup(input_df):
    table=input_df.select("type","Client_Computer","IP_Address","OS","Client_User", \
        "Content_Policy","Destination_Type","Destination","Device_Serial","File_Name",\
            "File_Size","Matched_Item","Item_Details","Date_Time_Server","Date_Time_Client", \
            "date","client_date","Event","Device_Type","Device","File_Type","Justification")
    return table
def querry(table):
    out_stream=table.writeStream \
    .partitionBy("Date","client_date","type","Content_Policy","Destination_Type", "Client_User") \
    .format("delta") \
    .outputMode("append") \
    .option("mergeSchema", "true") \
    .option("checkpointLocation", checkpoint_path) \
    .trigger(processingTime='20 seconds') \
    .start(output_path)
    out_stream.awaitTermination() 

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: ReportingLayer.py <input_path> <output_path> <checkpoint_path>", file=sys.stderr)
        sys.exit(-1) 
    input_path = sys.argv[1]
    output_path = sys.argv[2]
    checkpoint_path = sys.argv[3]
    spark = SparkSession.builder.getOrCreate()
    input_df=inputData(input_path)
    #choose the data you want to visualise.
    table=tableSetup(input_df)
    querry(table)
  
