#!/usr/bin/env python
__filename__ = "ndpl_dlp_processed.py"
__author__ = "Mohammed Munais"
__email__ = "mohammed.munais@nestgroup.net"
__date__ = "20/12/2022"
__status__ = "Production"
__description__ = """ This code uses Pyspark to read streaming data from raw layer Delta S3 bucket. Transformations are applied
                      on the data to split incoming message into respective columns. Resulting data is then pushed into 
                      the process layer Delta S3 bucket. """
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
def inputData(input_path):
    spark = SparkSession.builder.getOrCreate()
    # Create DataFrame representing the stream of input lines from connection to host:port
    input_df = spark.readStream.format("delta").load(input_path)
    filtered_input_df = input_df.filter(col("message").rlike("- Device Control -") | col("message").rlike("- Content Aware Protection -"))
    return filtered_input_df

def parsedData(filtered_input_df):
        schema = StructType([StructField("appname",StringType(),True),StructField("facility",StringType(),True),
        StructField("host",StringType(),True),StructField("hostname", StringType(), True),StructField("message", StringType(), True),
        StructField("procid", IntegerType(), True),StructField("severity",StringType(),True),StructField("source_ip",StringType(),True),
        StructField("source_type",StringType(),True),StructField("timestamp", StringType(), True),StructField("version", StringType(), True) ])
        parsed_df = filtered_input_df.select(from_json(col("message"), schema).alias("dlp_message")) \
            .select(col("dlp_message.*")) \
            .withColumn("EPP_IP", regexp_extract(col("message"), "EPP IP - (.*?) ", 1)) \
            .withColumn("type", regexp_extract(col("message"), "EPP IP -(.*?) - (.*?) -", 2)) \
            .withColumn("Log_ID", regexp_extract(col("message"), "\\[Log ID\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Client_Computer", regexp_extract(col("message"), "\\[Client Computer\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("IP_Address", regexp_extract(col("message"), "\\[IP Address\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("MAC_Address", regexp_extract(col("message"), "\\[MAC Address\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Serial_Number", regexp_extract(col("message"), "\\[Serial Number\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("OS", regexp_extract(col("message"), "\\[OS\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Client_User", regexp_extract(col("message"), "\\[Client User\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Content_Policy", regexp_extract(col("message"), "\\[Content Policy\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Content_Policy_Type",
                        regexp_extract(col("message"), "\\[Content Policy Type\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Destination_Type", regexp_extract(col("message"), "\\[Destination Type\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Destination", regexp_extract(col("message"), "\\[Destination\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Device_VID", regexp_extract(col("message"), "\\[Device VID\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Device_PID", regexp_extract(col("message"), "\\[Device PID\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Device_Serial", regexp_extract(col("message"), "\\[Device Serial\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("EPP_Client_Version",
                        regexp_extract(col("message"), "\\[EPP Client Version\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("File_Name", regexp_extract(col("message"), "\\[File Name\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("File_Hash", regexp_extract(col("message"), "\\[File Hash\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("File_Size", regexp_extract(col("message"), "\\[File Size\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Matched_Item", regexp_extract(col("message"), "\\[Matched Item\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Item_Details", regexp_extract(col("message"), "\\[Item Details\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Date_Time_Server",
                        regexp_extract(col("message"), "\\[Date\\/Time\\(Server\\)\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Date_Time_Client",
                        regexp_extract(col("message"), "\\[Date\\/Time\\(Client\\)\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Date_Time_Server_UTC",
                        regexp_extract(col("message"), "\\[Date\\/Time\\(Server UTC\\)\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Date_Time_Client_UTC",
                        regexp_extract(col("message"), "\\[Date\\/Time\\(Client UTC\\)\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("date", to_date(col("Date_Time_Server"))) \
            .withColumn("client_date", to_date(col("Date_Time_Client"))) \
            .withColumn("Event", regexp_extract(col("message"), "EPP IP -(.*?) - (.*?) - (.*?):", 3)) \
            .withColumn("Event_Name", regexp_extract(col("message"), "\\[Event Name\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Device_Type", regexp_extract(col("message"), "\\[Device Type\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Device", regexp_extract(col("message"), "\\[Device\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("EPP_Client_Version", regexp_extract(col("message"), "\\[EPP Client Version\\] (.*?)(?: \\||$)", 1))\
            .withColumn("File_Type", regexp_extract(col("message"), "\\[File Type\\] (.*?)(?: \\||$)", 1))\
            .withColumn("Justification", regexp_extract(col("message"), "\\[Justification\\] (.*?)(?: \\||$)", 1))\
            .drop(col("message"))
        parsed_df=parsed_df.select([when(col(c)=="","NA").otherwise(col(c)).alias(c) for c in parsed_df.columns])
        return parsed_df
def queryRun(parsed_df):
    out_stream=parsed_df.writeStream \
        .partitionBy("date","type") \
        .format("delta") \
        .outputMode("append") \
        .option("mergeSchema", "true") \
        .option("checkpointLocation", checkpoint_path) \
        .trigger(processingTime='20 seconds') \
        .start(output_path)
    out_stream.awaitTermination()
 
if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: process_layer_code.py <input_path> <output_path> <checkpoint_path>", file=sys.stderr)
        sys.exit(-1)
    # RECEIVING ARGUMENTS ENTERED IN COMMAND LINE USING SYS:
    input_path= sys.argv[1]
    checkpoint_path = sys.argv[2]
    output_path = sys.argv[3]
    # filter raw-data with the pattern in log 
    filtered_input_df=inputData(input_path)
    #data organisation, data cleaning, and table storage
    parsed_df=parsedData(filtered_input_df)
    queryRun(parsed_df)