# !/usr/bin/env python
__filename__ = "ndpl_dlp_reporting.py"
__author__ = "Mohammed Munais"
__email__ = "mohammed.munais@nestgroup.net"
__date__ = "20/12/2022"
__status__ = "Production"
__description__ = """ This code uses Pyspark to read streaming data from process layer Delta S3 bucket.This data is then pushed into 
                      the reporting layer in every 1 hour time interval Delta S3 bucket. """

import sys
from pyspark.sql import *
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.streaming import *
from pyspark import SparkContext
from pyspark import StorageLevel
import threading
from delta.tables import *

# from delta.tables import delta
import pyspark.sql.functions as F
from datetime import date
from datetime import datetime
from datetime import timedelta
import pytz
# inputData function ensure that only the most recent data is loaded, not the entire data, to save unnecessary processing.
def inputData(input_path):
    # today = date.today()
    spark = SparkSession.builder.getOrCreate()
    in_df = spark.read.format("delta").load(input_path)
    return in_df
def process(in_df):
    tz = pytz.timezone('Asia/Kolkata')
    ts = datetime.now(tz).date()
    ts2 = datetime.now()
    ts3 =ts2.strftime('%Y%m%d %H')
    in_df=in_df.where(col('date').isin(ts, ts-timedelta(days=1)))
    in_df_filtered = in_df.where(((to_timestamp(lit(ts3),'yyyyMMdd HH').cast('long') - to_timestamp(col("Date_Time_Server_UTC")).cast('long'))/3600 < 1) & \
                     ((to_timestamp(lit(ts3),'yyyyMMdd HH').cast('long') - to_timestamp(col("Date_Time_Server_UTC")).cast('long'))/3600 >= 0)) # assuming current timestamp in UTC
    dfPersist = in_df_filtered.select('date','Content_Policy','Destination_Type','Destination','Client_User','Matched_Item','Item_Details', \
        'type',"Device_Type","Event").persist(StorageLevel.MEMORY_AND_DISK)
    content_aware=dfPersist.filter(col('type') =='Content Aware Protection') \
     .groupBy('date','Content_Policy','Destination_Type','Destination','Client_User','Matched_Item','Item_Details').count() 
    device_control=dfPersist.filter(col('type') == 'Device Control') \
    .groupBy("date","Device_Type","Event","Client_User").count() 
    return content_aware,device_control;
def outputData(content_aware,device_control):
    # dfPersist.show(false)
    # table1 for content aware
    # dfPersist.filter(col('type') =='Content Aware Protection') \
    # .groupBy('date','Content_Policy','Destination_Type','Destination','Client_User','Matched_Item','Item_Details').count() 
    content_aware \
    .coalesce(2) \
    .write \
    .partitionBy('date') \
    .mode("append") \
    .parquet(output_path)
    # table2 for content_aware
    # dfPersist.filter(col('type') == 'Device Control') \
    # .groupBy("date","Device_Type","Event","Client_User").count() \
    device_control \
    .coalesce(2) \
    .write \
    .partitionBy("date") \
    .mode("append") \
    .parquet(output_path2)
    
if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: ReportingLayer.py <input_path> <output_path> <output_path2>", file=sys.stderr)
        sys.exit(-1) 
    input_path = sys.argv[1]
    output_path = sys.argv[2]
    output_path2 = sys.argv[3]
    spark = SparkSession.builder.getOrCreate()
    input_df=inputData(input_path)
    processing=process(input_df)
    content_aware,device_control = process(input_df)
    outputData(content_aware,device_control)