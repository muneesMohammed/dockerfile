import unittest
from etl.ndpl_dlp_raw import parseData
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, StructField, StringType
class Testndpl_dlp_raw(unittest.TestCase):
    def test_parse(self):
        spark = SparkSession.builder.appName(
            'sparkdf').getOrCreate()
        data=[
                    """{"message":"1022 <132>1 2023-01-25T19:52:34+05:30 eppserver EPP-dlplog.te.nestdigital.com 10511 - - EPP IP - ve9mx6g.hosted.endpointprotector.com - Device Control - File Copy: [Log ID] 69f1127587918a93790a0fd2b550a167 | [Event Name] File Copy | [Client Computer] NTP-LAP-330 | [IP Address] 192.168.1.9 | [MAC Address] f4-7b-09-27-bc-08 | [Serial Number] 7RBB9G3 | [OS] Windows 10 Pro x64 22H2  (19045.2364) | [Client User] Sheeja | [Device Type] Network Share | [Device] 10.15.10.119 (Network Share)/Microsoft | [Device VID] 0 | [Device PID] 0 | [Device Serial] 10.15.10.119 | [EPP Client Version] 5.8.4.1 | [File Name] //10.15.10.119/wps/WPS_FH/UAEWPS_Service/NeSTMODEL.pdb -> //10.15.10.119/wps/WPS_FH/Backup/25Jan2023/UAEWPS_Service/NeSTMODEL.pdb | [File Hash]  | [File Type] Program Debug Database | [File Size] 101888 | [Justification]  | [Time Interval]  | [Date/Time(Server)] 2023-01-25 19:52:34 | [Date/Time(Client)] 2023-01-25 19:52:30 | [Date/Time(Server UTC)] 2023-01-25T14:22:34Z | [Date/Time(Client UTC)] 2023-01-25T14:22:30Z"}""", 
                    """{"message":"1021 <132>1 2023-01-25T19:52:34+05:30 eppserver EPP-dlplog.te.nestdigital.com 10506 - - EPP IP - ve9mx6g.hosted.endpointprotector.com - Device Control - File Copy: [Log ID] b473a5b3bf0fb5ddb6f579a94aafa644 | [Event Name] File Copy | [Client Computer] NTP-LAP-330 | [IP Address] 192.168.1.9 | [MAC Address] f4-7b-09-27-bc-08 | [Serial Number] 7RBB9G3 | [OS] Windows 10 Pro x64 22H2  (19045.2364) | [Client User] Sheeja | [Device Type] Network Share | [Device] 10.15.10.119 (Network Share)/Microsoft | [Device VID] 0 | [Device PID] 0 | [Device Serial] 10.15.10.119 | [EPP Client Version] 5.8.4.1 | [File Name] //10.15.10.119/wps/WPS_FH/UAEWPS_Service/NeSTMODEL.dll -> //10.15.10.119/wps/WPS_FH/Backup/25Jan2023/UAEWPS_Service/NeSTMODEL.dll | [File Hash]  | [File Type] Application Extension | [File Size] 310784 | [Justification]  | [Time Interval]  | [Date/Time(Server)] 2023-01-25 19:52:34 | [Date/Time(Client)] 2023-01-25 19:52:22 | [Date/Time(Server UTC)] 2023-01-25T14:22:34Z | [Date/Time(Client UTC)] 2023-01-25T14:22:22Z"}""",
                    """{"appname":"EPP-vector.dlp.te.nestdigital.com","facility":"local0","host":"eppserver","hostname":"eppserver","message":"EPP IP - ve9mx6g.hosted.endpointprotector.com - Content Aware Protection - Content Threat Detected: [Log ID] 4e1c5bba5c180a8bb45c81d31d888d17 | [Client Computer] NTP-LAP-253 | [IP Address] 192.168.1.5 | [MAC Address] dc-21-5c-07-b8-86 | [Serial Number] 8GN54B3 | [OS]  | [Client User] Akhil.Avirachan | [Content Policy] HRG Department General policy | [Content Policy Type] 1 | [Destination Type] Network Share | [Destination] 10.8.0.41 (Network Share) | [Device VID] 0 | [Device PID] 0 | [Device Serial] 10.8.0.41 | [File Name] //10.8.0.41/LogonScripts/LogonPopup.exe | [File Hash] f450a37357e3c0d8223789aebe69cfcb | [File Size] 10240 | [Matched Item] application/x-dosexec | [Item Details] exe, sys, dll | [Date/Time(Server)] 2022-12-20 10:04:12 | [Date/Time(Client)] 2022-12-20 09:52:30 | [Date/Time(Server UTC)] 2022-12-20T04:34:12Z | [Date/Time(Client UTC)] 2022-12-20T04:22:30Z","procid":4241,"severity":"crit","source_ip":"10.0.5.125","source_type":"syslog","timestamp":"2022-12-20T04:34:12Z","version":1}"""
                    ]
        df3 = spark.createDataFrame(data, StringType()).toDF("value")
        # schema2 = StructType([ 
        #     StructField("value", StringType(), True)])
        # df3 = spark.createDataFrame(data=data, schema=schema2)


        testdata = [(
                    """{"message":"1022 <132>1 2023-01-25T19:52:34+05:30 eppserver EPP-dlplog.te.nestdigital.com 10511 - - EPP IP - ve9mx6g.hosted.endpointprotector.com - Device Control - File Copy: [Log ID] 69f1127587918a93790a0fd2b550a167 | [Event Name] File Copy | [Client Computer] NTP-LAP-330 | [IP Address] 192.168.1.9 | [MAC Address] f4-7b-09-27-bc-08 | [Serial Number] 7RBB9G3 | [OS] Windows 10 Pro x64 22H2  (19045.2364) | [Client User] Sheeja | [Device Type] Network Share | [Device] 10.15.10.119 (Network Share)/Microsoft | [Device VID] 0 | [Device PID] 0 | [Device Serial] 10.15.10.119 | [EPP Client Version] 5.8.4.1 | [File Name] //10.15.10.119/wps/WPS_FH/UAEWPS_Service/NeSTMODEL.pdb -> //10.15.10.119/wps/WPS_FH/Backup/25Jan2023/UAEWPS_Service/NeSTMODEL.pdb | [File Hash]  | [File Type] Program Debug Database | [File Size] 101888 | [Justification]  | [Time Interval]  | [Date/Time(Server)] 2023-01-25 19:52:34 | [Date/Time(Client)] 2023-01-25 19:52:30 | [Date/Time(Server UTC)] 2023-01-25T14:22:34Z | [Date/Time(Client UTC)] 2023-01-25T14:22:30Z"}""",
                    "2023-01-25 19:52:34", "2023-01-25", "69f1127587918a93790a0fd2b550a167"), (
                    """{"message":"1021 <132>1 2023-01-25T19:52:34+05:30 eppserver EPP-dlplog.te.nestdigital.com 10506 - - EPP IP - ve9mx6g.hosted.endpointprotector.com - Device Control - File Copy: [Log ID] b473a5b3bf0fb5ddb6f579a94aafa644 | [Event Name] File Copy | [Client Computer] NTP-LAP-330 | [IP Address] 192.168.1.9 | [MAC Address] f4-7b-09-27-bc-08 | [Serial Number] 7RBB9G3 | [OS] Windows 10 Pro x64 22H2  (19045.2364) | [Client User] Sheeja | [Device Type] Network Share | [Device] 10.15.10.119 (Network Share)/Microsoft | [Device VID] 0 | [Device PID] 0 | [Device Serial] 10.15.10.119 | [EPP Client Version] 5.8.4.1 | [File Name] //10.15.10.119/wps/WPS_FH/UAEWPS_Service/NeSTMODEL.dll -> //10.15.10.119/wps/WPS_FH/Backup/25Jan2023/UAEWPS_Service/NeSTMODEL.dll | [File Hash]  | [File Type] Application Extension | [File Size] 310784 | [Justification]  | [Time Interval]  | [Date/Time(Server)] 2023-01-25 19:52:34 | [Date/Time(Client)] 2023-01-25 19:52:22 | [Date/Time(Server UTC)] 2023-01-25T14:22:34Z | [Date/Time(Client UTC)] 2023-01-25T14:22:22Z"}""",
                    "2023-01-25 19:52:34", "2023-01-25",
                    "b473a5b3bf0fb5ddb6f579a94aafa644"),
                    ("""{"appname":"EPP-vector.dlp.te.nestdigital.com","facility":"local0","host":"eppserver","hostname":"eppserver","message":"EPP IP - ve9mx6g.hosted.endpointprotector.com - Content Aware Protection - Content Threat Detected: [Log ID] 4e1c5bba5c180a8bb45c81d31d888d17 | [Client Computer] NTP-LAP-253 | [IP Address] 192.168.1.5 | [MAC Address] dc-21-5c-07-b8-86 | [Serial Number] 8GN54B3 | [OS]  | [Client User] Akhil.Avirachan | [Content Policy] HRG Department General policy | [Content Policy Type] 1 | [Destination Type] Network Share | [Destination] 10.8.0.41 (Network Share) | [Device VID] 0 | [Device PID] 0 | [Device Serial] 10.8.0.41 | [File Name] //10.8.0.41/LogonScripts/LogonPopup.exe | [File Hash] f450a37357e3c0d8223789aebe69cfcb | [File Size] 10240 | [Matched Item] application/x-dosexec | [Item Details] exe, sys, dll | [Date/Time(Server)] 2022-12-20 10:04:12 | [Date/Time(Client)] 2022-12-20 09:52:30 | [Date/Time(Server UTC)] 2022-12-20T04:34:12Z | [Date/Time(Client UTC)] 2022-12-20T04:22:30Z","procid":4241,"severity":"crit","source_ip":"10.0.5.125","source_type":"syslog","timestamp":"2022-12-20T04:34:12Z","version":1}""",
                     "2022-12-20 10:04:12","2022-12-20","4e1c5bba5c180a8bb45c81d31d888d17")]  # specify column names
        schema = StructType([ \
        StructField("message", StringType(), True), \
            StructField("timestamp", StringType(), True), \
            StructField("date", StringType(), True), \
            StructField("uuid", StringType(), True)])
        df = spark.createDataFrame(data=testdata, schema=schema).select(col("message"),col("timestamp"),to_date(col("date")).alias("date"),col("uuid"))



        parsed = parseData(df3)
        self.assertEqual(parsed.schema, df.schema)

        self.assertEqual(parsed.collect(), df.collect())
        # col1=parsed.collect
        # col2=df.collect
        # self.assertEqual(col1, col2)


        # with self.assertRaises(ValueError):
        #     ndpl_dlp_raw.divide(10, 0)


if __name__ == '__main__':
    # parsed=rawtest.parseData("C:\\Users\\Munees\\PycharmProjects\\sparkProject\\data\\filecount123.json")
    # RECEIVING ARGUMENTS ENTERED IN COMMAND LINE USING SYS:
    
    unittest.main()