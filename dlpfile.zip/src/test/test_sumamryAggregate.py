import unittest
from etl.ndpl_dlp_reporting_summaryAggregate import process
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from datetime import datetime
from datetime import timedelta
from pyspark import StorageLevel
import pytz
from pyspark.sql.types import StructType, StructField, StringType,IntegerType
class Testndpl_dlp_raw(unittest.TestCase):
    def test_processed(self):
        # spark = SparkSession.builder.appName('sparkdf').getOrCreate()
        spark = SparkSession.builder.master("local").appName('Json File').config('spark.jars.packages','io.delta:delta-core_2.12:2.1.0').getOrCreate()
        # sc = spark.sparkContext
        # input_path = "C:\\Users\\Munees\\PycharmProjects\\sparkProject\\data\\filecount123.json"
        # input_df = spark.read.text(input_path)
        data=[
            """{"message":"1022 <132>1 2023-01-25T19:52:34+05:30 eppserver EPP-dlplog.te.nestdigital.com 10511 - - EPP IP - ve9mx6g.hosted.endpointprotector.com - Device Control - File Copy: [Log ID] 69f1127587918a93790a0fd2b550a167 | [Event Name] File Copy | [Client Computer] NTP-LAP-330 | [IP Address] 192.168.1.9 | [MAC Address] f4-7b-09-27-bc-08 | [Serial Number] 7RBB9G3 | [OS] Windows 10 Pro x64 22H2  (19045.2364) | [Client User] Sheeja | [Device Type] Network Share | [Device] 10.15.10.119 (Network Share)/Microsoft | [Device VID] 0 | [Device PID] 0 | [Device Serial] 10.15.10.119 | [EPP Client Version] 5.8.4.1 | [File Name] //10.15.10.119/wps/WPS_FH/UAEWPS_Service/NeSTMODEL.pdb -> //10.15.10.119/wps/WPS_FH/Backup/25Jan2023/UAEWPS_Service/NeSTMODEL.pdb | [File Hash]  | [File Type] Program Debug Database | [File Size] 101888 | [Justification]  | [Time Interval]  | [Date/Time(Server)] 2023-01-25 19:52:34 | [Date/Time(Client)] 2023-01-25 19:52:30 | [Date/Time(Server UTC)] 2023-01-25T14:22:34Z | [Date/Time(Client UTC)] 2023-01-25T14:22:30Z"}""", 
            """{"message":"1021 <132>1 2023-01-25T19:52:34+05:30 eppserver EPP-dlplog.te.nestdigital.com 10506 - - EPP IP - ve9mx6g.hosted.endpointprotector.com - Device Control - File Copy: [Log ID] b473a5b3bf0fb5ddb6f579a94aafa644 | [Event Name] File Copy | [Client Computer] NTP-LAP-330 | [IP Address] 192.168.1.9 | [MAC Address] f4-7b-09-27-bc-08 | [Serial Number] 7RBB9G3 | [OS] Windows 10 Pro x64 22H2  (19045.2364) | [Client User] Sheeja | [Device Type] Network Share | [Device] 10.15.10.119 (Network Share)/Microsoft | [Device VID] 0 | [Device PID] 0 | [Device Serial] 10.15.10.119 | [EPP Client Version] 5.8.4.1 | [File Name] //10.15.10.119/wps/WPS_FH/UAEWPS_Service/NeSTMODEL.dll -> //10.15.10.119/wps/WPS_FH/Backup/25Jan2023/UAEWPS_Service/NeSTMODEL.dll | [File Hash]  | [File Type] Application Extension | [File Size] 310784 | [Justification]  | [Time Interval]  | [Date/Time(Server)] 2023-01-25 19:52:34 | [Date/Time(Client)] 2023-01-25 19:52:22 | [Date/Time(Server UTC)] 2023-01-25T14:22:34Z | [Date/Time(Client UTC)] 2023-01-25T14:22:22Z"}""",
            """{"appname":"EPP-vector.dlp.te.nestdigital.com","facility":"local0","host":"eppserver","hostname":"eppserver","message":"EPP IP - ve9mx6g.hosted.endpointprotector.com - Content Aware Protection - Content Threat Detected: [Log ID] 4e1c5bba5c180a8bb45c81d31d888d17 | [Client Computer] NTP-LAP-253 | [IP Address] 192.168.1.5 | [MAC Address] dc-21-5c-07-b8-86 | [Serial Number] 8GN54B3 | [OS]  | [Client User] Akhil.Avirachan | [Content Policy] HRG Department General policy | [Content Policy Type] 1 | [Destination Type] Network Share | [Destination] 10.8.0.41 (Network Share) | [Device VID] 0 | [Device PID] 0 | [Device Serial] 10.8.0.41 | [File Name] //10.8.0.41/LogonScripts/LogonPopup.exe | [File Hash] f450a37357e3c0d8223789aebe69cfcb | [File Size] 10240 | [Matched Item] application/x-dosexec | [Item Details] exe, sys, dll | [Date/Time(Server)] 2022-12-20 10:04:12 | [Date/Time(Client)] 2022-12-20 09:52:30 | [Date/Time(Server UTC)] 2022-12-20T04:34:12Z | [Date/Time(Client UTC)] 2022-12-20T04:22:30Z","procid":4241,"severity":"crit","source_ip":"10.0.5.125","source_type":"syslog","timestamp":"2022-12-20T04:34:12Z","version":1}"""
            ]
        input_df = spark.createDataFrame(data, StringType()).toDF("value")
        input_df = input_df.filter(
            col("value").rlike("- Device Control -") | col("value").rlike("- Content Aware Protection -"))
        schema = StructType([StructField("appname", StringType(), True), StructField("facility", StringType(), True),
                             StructField("host", StringType(), True), StructField("hostname", StringType(), True),
                             StructField("message", StringType(), True),
                             StructField("procid", IntegerType(), True), StructField("severity", StringType(), True),
                             StructField("source_ip", StringType(), True),
                             StructField("source_type", StringType(), True),
                             StructField("timestamp", StringType(), True),
                             StructField("version", StringType(), True)])

        df2 = input_df.select(from_json('value', schema).alias("dlp_message")) \
            .select(col("dlp_message.*")) \
            .withColumn("EPP_IP", regexp_extract(col("message"), "EPP IP - (.*?) ", 1)) \
            .withColumn("type", regexp_extract(col("message"), "EPP IP -(.*?) - (.*?) -", 2)) \
            .withColumn("Log_ID", regexp_extract(col("message"), "\\[Log ID\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Client_Computer", regexp_extract(col("message"), "\\[Client Computer\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("IP_Address", regexp_extract(col("message"), "\\[IP Address\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("MAC_Address", regexp_extract(col("message"), "\\[MAC Address\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Serial_Number", regexp_extract(col("message"), "\\[Serial Number\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("OS", regexp_extract(col("message"), "\\[OS\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Client_User", regexp_extract(col("message"), "\\[Client User\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Content_Policy", regexp_extract(col("message"), "\\[Content Policy\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Content_Policy_Type",
                        regexp_extract(col("message"), "\\[Content Policy Type\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Destination_Type", regexp_extract(col("message"), "\\[Destination Type\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Destination", regexp_extract(col("message"), "\\[Destination\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Device_VID", regexp_extract(col("message"), "\\[Device VID\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Device_PID", regexp_extract(col("message"), "\\[Device PID\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Device_Serial", regexp_extract(col("message"), "\\[Device Serial\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("EPP_Client_Version",
                        regexp_extract(col("message"), "\\[EPP Client Version\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("File_Name", regexp_extract(col("message"), "\\[File Name\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("File_Hash", regexp_extract(col("message"), "\\[File Hash\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("File_Size", regexp_extract(col("message"), "\\[File Size\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Matched_Item", regexp_extract(col("message"), "\\[Matched Item\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Item_Details", regexp_extract(col("message"), "\\[Item Details\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Date_Time_Server",
                        regexp_extract(col("message"), "\\[Date\\/Time\\(Server\\)\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Date_Time_Client",
                        regexp_extract(col("message"), "\\[Date\\/Time\\(Client\\)\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Date_Time_Server_UTC",
                        regexp_extract(col("message"), "\\[Date\\/Time\\(Server UTC\\)\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Date_Time_Client_UTC",
                        regexp_extract(col("message"), "\\[Date\\/Time\\(Client UTC\\)\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("date", to_date(col("Date_Time_Server"))) \
            .withColumn("client_date", to_date(col("Date_Time_Client"))) \
            .withColumn("Event", regexp_extract(col("message"), "EPP IP -(.*?) - (.*?) - (.*?):", 3)) \
            .withColumn("Event_Name", regexp_extract(col("message"), "\\[Event Name\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Device_Type", regexp_extract(col("message"), "\\[Device Type\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Device", regexp_extract(col("message"), "\\[Device\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("EPP_Client_Version",
                        regexp_extract(col("message"), "\\[EPP Client Version\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("File_Type", regexp_extract(col("message"), "\\[File Type\\] (.*?)(?: \\||$)", 1)) \
            .withColumn("Justification", regexp_extract(col("message"), "\\[Justification\\] (.*?)(?: \\||$)", 1)) \
            .drop(col("message"))
        df2 = df2.select([when(col(c) == "", "NA").otherwise(col(c)).alias(c) for c in df2.columns])

        tz = pytz.timezone('Asia/Kolkata')
        ts = datetime.now(tz).date()
        ts2 = datetime.now()
        ts3 = ts2.strftime('%Y%m%d %H')
        tz = pytz.timezone('Asia/Kolkata')




        # in_df = df2.where(df2.date > ts - timedelta(days=100))
        in_df = df2.where(col('date').isin(ts, ts - timedelta(days=1)))

        in_df_filtered = in_df.where(((to_timestamp(lit(ts3), 'yyyyMMdd HH').cast('long') - to_timestamp(
            col("Date_Time_Server_UTC")).cast('long')) / 3600 < 1) & \
                                     ((to_timestamp(lit(ts3), 'yyyyMMdd HH').cast('long') - to_timestamp(
                                         col("Date_Time_Server_UTC")).cast(
                                         'long')) / 3600 >= 0))  # assuming current timestamp in UTC
        dfPersist = in_df_filtered.select('date', 'Content_Policy', 'Destination_Type', 'Destination', 'Client_User',
                                          'Matched_Item', 'Item_Details', \
                                          'type', "Device_Type", "Event").persist(StorageLevel.MEMORY_AND_DISK)
        content_aware = dfPersist.filter(col('type') == 'Content Aware Protection') \
            .groupBy('date', 'Content_Policy', 'Destination_Type', 'Destination', 'Client_User', 'Matched_Item',
                     'Item_Details').count()
        device_control = dfPersist.filter(col('type') == 'Device Control') \
            .groupBy("date", "Device_Type", "Event", "Client_User").count()

        summaryagri = process(df2)
        summcontent=summaryagri[0]
        summdevice=summaryagri[1]
        self.assertEqual(summcontent.schema, content_aware.schema)
        self.assertEqual(summdevice.schema, device_control.schema)
        self.assertEqual(summcontent.collect(), content_aware.collect())
        self.assertEqual(summdevice.collect(), device_control.collect())



if __name__ == '__main__':
    # parsed=rawtest.parseData("C:\\Users\\Munees\\PycharmProjects\\sparkProject\\data\\filecount123.json"

    unittest.main()