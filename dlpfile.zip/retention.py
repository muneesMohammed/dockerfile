    #!/usr/bin/env python
__filename__ = "ndpl_dlp_reporting.py"
__author__ = "Mohammed Munais"
__email__ = "mohammed.munais@nestgroup.net"
__date__ = "20/12/2022"
__status__ = "Production"
__description__ = """ This code uses Pyspark to read streaming data from process layer Delta S3 bucket.This data is then pushed into 
                      the reporting layer Delta S3 bucket. """

import sys
from pyspark.sql import *
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.streaming import *
from pyspark import SparkContext
import threading
from delta.tables import *
# from delta.tables import delta
import pyspark.sql.functions as F
from datetime import datetime
# from datetime import timedelta
# from datetime import date
from pyspark.sql.functions import *
import os, uuid
from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient
import os
from azure.storage.blob import BlobServiceClient
import re
from pyspark.sql.types import DateType
from datetime import datetime
from datetime import timedelta
from delta.tables import *



def monthRet(input_path): 
    spark = SparkSession.builder.config("spark.databricks.delta.retentionDurationCheck.enabled", "false").getOrCreate()
    deltaTable = DeltaTable.forPath(spark,input_path) 
    deltaTable.logRetentionDuration = "interval 30 days"
    deltaTable.deletedFileRetentionDuration = "interval 1 days"
    # deltaTable.vacuum()
    # spark.sql("VACUUM delta.{0}".format(input_pathá)).show()

def yearret(input_path):
    spark = SparkSession.builder.config("spark.databricks.delta.retentionDurationCheck.enabled", "false").getOrCreate()
    deltaTable = DeltaTable.forPath(spark,input_path) 
    deltaTable.logRetentionDuration = "interval 360 days"
    deltaTable.deletedFileRetentionDuration = "interval 1 days"
    # deltaTable.vacuum()
def sixret(input_path):
    spark = SparkSession.builder.config("spark.databricks.delta.retentionDurationCheck.enabled", "false").getOrCreate()
    deltaTable = DeltaTable.forPath(spark,input_path) 
    deltaTable.logRetentionDuration = "interval 180 days"
    deltaTable.deletedFileRetentionDuration = "interval 1 days"
    #  deltaTable.vacuum()
        
if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: ReportingLayer.py <input_path_reporting> <input_path_Processes> <input_path_raw>", file=sys.stderr)
        sys.exit(-1) 
    input_path_reporting = sys.argv[1]
    input_path_Processes = sys.argv[2]
    input_path_raw = sys.argv[3]
    # removing information from the reporting layer that is older than 30 days
    monthRet(input_path_reporting)
    # removing information from the raw layer that is older than a year
    yearret(input_path_raw)
    # removing information from the process layer that is older than 6 months
    sixret(input_path_Processes)
